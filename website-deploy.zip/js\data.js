/**
 * Himalayan Vistas Tours & Travels - Master Configuration & Data File
 * 
 * 100% Tested & Verified High-Resolution Image URLs
 */

const travelAgencyData = {
  business: {
    name: "Himalayan Vistas Tours & Travels",
    tagline: "Your Gateway to Himachal & Uttarakhand",
    subtagline: "Handcrafted journeys across snow-clad peaks, sacred rivers, and alpine meadows.",
    established: "2018",
    rating: "4.9",
    totalReviews: "1,850+",
    happyTravelers: "25,000+",
    location: "Mall Road, Manali, Himachal Pradesh - 175131, India",
    branches: ["Manali (Head Office)", "Shimla", "Rishikesh", "Dehradun"],
    contact: {
      phone: "+91 98765 43210",
      altPhone: "+91 98123 45678",
      whatsapp: "919876543210",
      email: "bookings@himalayanvistas.com",
      supportEmail: "support@himalayanvistas.com",
      workingHours: "Mon - Sun: 8:00 AM - 10:00 PM (IST)"
    },
    socials: {
      instagram: "https://instagram.com",
      facebook: "https://facebook.com",
      youtube: "https://youtube.com",
      tripadvisor: "https://tripadvisor.com"
    },
    usp: [
      {
        icon: "compass",
        title: "100% Local Himalayan Experts",
        desc: "Born & raised in the hills. We take you beyond tourist traps to authentic hidden spots."
      },
      {
        icon: "shield-check",
        title: "Safe & Verified Stays",
        desc: "Handpicked boutique hotels, premium riverside luxury camps, and certified homestays."
      },
      {
        icon: "car",
        title: "Expert Mountain Drivers",
        desc: "Commercial certified hill drivers with well-maintained 4x4 SUVs and luxury tempo travelers."
      },
      {
        icon: "headphones",
        title: "24/7 On-Ground Support",
        desc: "Dedicated personal trip manager assigned from arrival to departure for complete peace of mind."
      }
    ]
  },

  destinations: [
    {
      id: "himachal",
      state: "Himachal Pradesh",
      tagline: "Land of the Gods & Snow-Capped Horizons",
      description: "From high-altitude cold deserts of Spiti to lush cedar valleys of Manali and colonial charms of Shimla.",
      bgImage: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?auto=format&fit=crop&w=1200&q=80",
      spots: [
        {
          name: "Manali & Solang Valley",
          tag: "Adventure & Romance",
          image: "https://images.unsplash.com/photo-1483921020237-2ff51e8e4b22?auto=format&fit=crop&w=800&q=80",
          desc: "Snow activities at Rohtang Pass, cafe culture in Old Manali, and serene pine forests."
        },
        {
          name: "Spiti Valley & Kaza",
          tag: "Rugged Trans-Himalaya",
          image: "https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?auto=format&fit=crop&w=800&q=80",
          desc: "1000-year-old monasteries, world's highest post office, and dramatic moonscapes."
        },
        {
          name: "Shimla & Kufri",
          tag: "Colonial Charm",
          image: "https://images.unsplash.com/photo-1597074866923-dc0589150358?auto=format&fit=crop&w=800&q=80",
          desc: "UNESCO toy train ride, heritage architecture, scenic Mall road, and snow-kissed ridges."
        },
        {
          name: "Dharamshala & Bir Billing",
          tag: "Spirituality & Paragliding",
          image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
          desc: "Home of the Dalai Lama, Tibetan monastery trails, and world's second-highest paragliding site."
        },
        {
          name: "Kasol & Jibhi",
          tag: "Offbeat Riverside Serenity",
          image: "https://images.unsplash.com/photo-1605649487212-47bdab064df7?auto=format&fit=crop&w=800&q=80",
          desc: "Tirthan valley crystal rivers, Kheerganga hot springs, and serene apple orchards."
        }
      ]
    },
    {
      id: "uttarakhand",
      state: "Uttarakhand",
      tagline: "Devbhoomi - Divine Lands & Thrilling Trails",
      description: "Sacred river confluences, holy Himalayan shrines, serene glacial lakes, and white-water rapids.",
      bgImage: "https://images.unsplash.com/photo-1544644181-1484b3fdfc62?auto=format&fit=crop&w=1200&q=80",
      spots: [
        {
          name: "Rishikesh & Haridwar",
          tag: "Yoga & River Rafting",
          image: "https://images.unsplash.com/photo-1544644181-1484b3fdfc62?auto=format&fit=crop&w=800&q=80",
          desc: "World capital of Yoga, vibrant Ganga Aarti at sunset, cliff jumping, and white-water rapids."
        },
        {
          name: "Kedarnath & Badrinath",
          tag: "Sacred Char Dham",
          image: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=800&q=80",
          desc: "Ancient stone temples surrounded by soaring snow-clad peaks and deep spiritual bliss."
        },
        {
          name: "Auli & Chopta",
          tag: "Skiing & Switzerland of India",
          image: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=800&q=80",
          desc: "Snow skiing meadows with Nanda Devi views and highest Shiva temple trek at Tungnath."
        },
        {
          name: "Nainital & Bhimtal",
          tag: "Emerald Lakes",
          image: "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=800&q=80",
          desc: "Gentle sailboat rides on pear-shaped lake, vintage cable car, and tranquil pine forests."
        },
        {
          name: "Jim Corbett National Park",
          tag: "Wild Jungle Safari",
          image: "https://images.unsplash.com/photo-1561731216-c3a4d99437d5?auto=format&fit=crop&w=800&q=80",
          desc: "Thrilling open-jeep tiger safaris, luxury jungle resorts by Kosi river, and bird watching."
        }
      ]
    }
  ],

  packages: [
    {
      id: "pkg-1",
      title: "Magical Himachal: Shimla & Manali Delight",
      state: "Himachal",
      category: "Family",
      duration: "6 Days / 5 Nights",
      price: 18499,
      originalPrice: 24999,
      discount: "26% OFF",
      rating: 4.9,
      reviewsCount: 148,
      badge: "Best Seller",
      badgeColor: "emerald",
      heroImage: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?auto=format&fit=crop&w=800&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1483921020237-2ff51e8e4b22?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1597074866923-dc0589150358?auto=format&fit=crop&w=800&q=80"
      ],
      route: "Chandigarh/Delhi - Shimla (2N) - Kullu - Manali (3N) - Solang Valley",
      inclusions: ["3-Star Mountain Hotels", "Daily Breakfast & Dinner", "Private Sedan / SUV Cab", "Driver Allowances & Tolls", "Sightseeing As Per Plan"],
      exclusions: ["Flight / Train tickets", "Rohtang Pass permit fees", "Adventure sports tickets", "Personal laundry & expenses"],
      overview: "Experience the quintessential Himalayan road trip. Stroll through the charming colonial Mall Road of Shimla, visit Kufri snow point, witness river rafting in Kullu, and revel in snow activities at Solang Valley and Atal Tunnel in Manali.",
      itinerary: [
        { day: "Day 1", title: "Delhi/Chandigarh to Shimla - Arrival & Evening Walk", detail: "Pick-up from Delhi or Chandigarh. Enjoy scenic drive through Shivalik ranges. Check-in to Shimla hotel. Evening free to explore Ridge and Mall Road." },
        { day: "Day 2", title: "Shimla & Kufri Snow Point Sightseeing", detail: "Morning excursion to Kufri for horse riding, yak rides, and Himalayan Nature Park. Visit Jakhoo Temple and Christ Church in the evening." },
        { day: "Day 3", title: "Shimla to Manali via Kullu Valley & Pandoh Dam", detail: "Scenic 7-8 hour drive passing Sundernagar Lake, Pandoh Dam, and Hanogi Mata Temple. Stop at Kullu for shawl factory visit and river rafting." },
        { day: "Day 4", title: "Manali Local Sightseeing & Old Manali Cafes", detail: "Visit historic Hadimba Devi Temple, Vashisht Hot Sulphur Springs, Tibetan Monastery, and Manu Temple in Old Manali." },
        { day: "Day 5", title: "Solang Valley Snow Point & Atal Tunnel Excursion", detail: "Full day excursion to Solang Valley for paragliding, zorbing, and quad biking. Drive through the engineering marvel Atal Tunnel to Sissu waterfall." },
        { day: "Day 6", title: "Manali to Delhi/Chandigarh Departure", detail: "Relish breakfast with pine valley views, check out and drive back to Chandigarh/Delhi airport or railway station with sweet memories." }
      ]
    },
    {
      id: "pkg-2",
      title: "Spiti Valley 4x4 Off-Road Expedition",
      state: "Himachal",
      category: "Adventure",
      duration: "9 Days / 8 Nights",
      price: 32999,
      originalPrice: 42000,
      discount: "21% OFF",
      rating: 5.0,
      reviewsCount: 96,
      badge: "Iconic Adventure",
      badgeColor: "amber",
      heroImage: "https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?auto=format&fit=crop&w=800&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1605649487212-47bdab064df7?auto=format&fit=crop&w=800&q=80"
      ],
      route: "Shimla - Sangla - Kalpa - Nako - Tabo - Kaza - Hikkim - Chandratal - Manali",
      inclusions: ["Dedicated 4x4 Mountain Vehicle", "Curated Homestays & Camps", "Breakfast & Dinner", "Experienced Spitian Tour Marshal", "Inner Line Permits"],
      exclusions: ["Personal medical insurance", "Fuel for personal bikes", "Any emergency evacuation costs", "Snacks & personal beverages"],
      overview: "Embark on India's most legendary mountain circuit. Traverse Hindustan-Tibet road, gaze at Kinnaur Kailash, visit 1,000-year-old Tabo & Key Monasteries, post a letter from Hikkim, and camp under milky way stars by turquoise Chandratal Lake.",
      itinerary: [
        { day: "Day 1-2", title: "Shimla to Kinnaur (Sarahan & Sangla)", detail: "Drive along Sutlej river. Visit Bhimakali Temple and enter Baspa valley to reach ancient Sangla." },
        { day: "Day 3", title: "Chitkul (Last Indian Village) to Kalpa", detail: "Explore Chitkul village border post. Drive to Kalpa with front-row sunset view of sacred Kinnaur Kailash." },
        { day: "Day 4", title: "Kalpa to Tabo via Nako Lake & Mummy of Gue", detail: "Witness terrain shift from green to cold trans-Himalayan desert. Visit 500-year-old preserved monk mummy at Gue." },
        { day: "Day 5-6", title: "Kaza, Key Monastery, Hikkim, Komik & Langza", detail: "Explore Key Gompa, send postcards from highest post office in Hikkim (14,567 ft), and search for fossils in Langza." },
        { day: "Day 7", title: "Kaza to Chandratal Lake via Kunzum Pass (14,931 ft)", detail: "Cross towering Kunzum Pass into Lahaul valley. Hike to crescent-shaped mystic Chandratal lake. Camp under billion stars." },
        { day: "Day 8-9", title: "Chandratal to Manali via Atal Tunnel & Return", detail: "Drive through Batal, Gramphu, and Atal Tunnel back to Manali. Transfer to Chandigarh for departure." }
      ]
    },
    {
      id: "pkg-3",
      title: "Sacred Kedarnath & Badrinath Do Dham Pilgrimage",
      state: "Uttarakhand",
      category: "Spiritual",
      duration: "6 Days / 5 Nights",
      price: 24500,
      originalPrice: 31000,
      discount: "20% OFF",
      rating: 4.9,
      reviewsCount: 220,
      badge: "Divine Yatra",
      badgeColor: "amber",
      heroImage: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=800&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1544644181-1484b3fdfc62?auto=format&fit=crop&w=800&q=80"
      ],
      route: "Haridwar/Rishikesh - Guptkashi - Kedarnath - Joshimath - Badrinath - Rishikesh",
      inclusions: ["Comfortable Hotel / Camp Stays", "Pure Vegetarian Meals (Breakfast & Dinner)", "Yatra Registration Assistance", "Dedicated Hill Vehicle (Innova/Tempo)", "Driver & Toll Charges"],
      exclusions: ["Helicopter / Pony / Palki tickets", "Personal pooja donations", "VIP darshan tokens", "Lunch on the road"],
      overview: "Experience profound spirituality at two of the holiest Himalayan abodes. Feel divine vibrations at the feet of Lord Shiva at Kedarnath Ji and Lord Vishnu at Badrinath Ji surrounded by Neelkanth peak.",
      itinerary: [
        { day: "Day 1", title: "Haridwar/Rishikesh to Guptkashi", detail: "Early morning pickup. Drive along scenic Mandakini and Alaknanda rivers via Devprayag & Rudraprayag confluences. Overnight at Guptkashi." },
        { day: "Day 2", title: "Guptkashi to Gaurikund & Kedarnath Trek (16 km)", detail: "Reach Gaurikund base. Trek or take pony/helicopter to holy Kedarnath shrine. Attend divine evening aarti amidst chanting devotees." },
        { day: "Day 3", title: "Morning Kedarnath Darshan & Trek Down to Guptkashi", detail: "Early morning sacred darshan and abhishek. Trek down to Gaurikund and relax at Guptkashi hotel." },
        { day: "Day 4", title: "Guptkashi to Badrinath via Chopta", detail: "Drive through scenic Chopta meadows to Badrinath. Evening darshan at Badrinath temple and dip in holy Tapt Kund." },
        { day: "Day 5", title: "Mana Village (First Indian Village) to Rudraprayag", detail: "Visit Mana village, Vyas Gufa, Bhim Pul, and origin of Saraswati river. Drive back to Rudraprayag for overnight stay." },
        { day: "Day 6", title: "Rudraprayag to Rishikesh / Haridwar Drop", detail: "Drive back along the Ganga. Attend soul-stirring Ganga Aarti at Parmarth Niketan or Har Ki Pauri before departure." }
      ]
    },
    {
      id: "pkg-4",
      title: "Auli Snow Skiing & Chopta Chandrashila Summit",
      state: "Uttarakhand",
      category: "Adventure",
      duration: "5 Days / 4 Nights",
      price: 16999,
      originalPrice: 22000,
      discount: "22% OFF",
      rating: 4.9,
      reviewsCount: 112,
      badge: "Snow & Peaks",
      badgeColor: "sky",
      heroImage: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=800&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80"
      ],
      route: "Rishikesh - Devprayag - Joshimath - Auli - Chopta - Chandrashila Summit - Rishikesh",
      inclusions: ["Scenic Swiss Camps & Cottages", "All Meals on Trek (Veg)", "Certified Ski / Trek Instructors", "Trek Permits & Safety Gear", "Shared or Private Mountain Transport"],
      exclusions: ["Auli Ropeway tickets", "Personal skiing gear rental", "Tips & porter charges", "Personal medication"],
      overview: "Witness 360-degree panoramic views of Nanda Devi, Trishul, and Chaukhamba peaks. Glide down pristine snow slopes in Auli, then summit Chandrashila peak after visiting the world's highest Shiva shrine at Tungnath.",
      itinerary: [
        { day: "Day 1", title: "Rishikesh to Joshimath", detail: "Scenic 8-hour drive crossing Bhagirathi-Alaknanda sangam. Check in to scenic cliffside cottage in Joshimath." },
        { day: "Day 2", title: "Auli Snow Skiing & Ropeway Ride", detail: "Board Asia's longest ropeway to Auli meadows. Skiing trial session with certified instructor and photography at Auli artificial lake." },
        { day: "Day 3", title: "Joshimath to Chopta Basecamp", detail: "Scenic transfer to Chopta, also known as the Mini Switzerland of India. Bonfire and music under starry night." },
        { day: "Day 4", title: "Trek to Tungnath (12,073 ft) & Chandrashila (13,123 ft)", detail: "Early morning trek through rhododendron forests. Reach 1000-yr old Tungnath temple and conquer Chandrashila summit for breathtaking sunrise." },
        { day: "Day 5", title: "Chopta to Rishikesh Drop", detail: "Descend to base and drive back to Rishikesh. Evening drop at bus terminal or railway station." }
      ]
    },
    {
      id: "pkg-5",
      title: "Romantic Nainital, Corbett & Mussoorie Escapade",
      state: "Uttarakhand",
      category: "Honeymoon",
      duration: "7 Days / 6 Nights",
      price: 26999,
      originalPrice: 34500,
      discount: "21% OFF",
      rating: 4.8,
      reviewsCount: 165,
      badge: "Couple Special",
      badgeColor: "rose",
      heroImage: "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=800&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1561731216-c3a4d99437d5?auto=format&fit=crop&w=800&q=80"
      ],
      route: "Delhi - Nainital (2N) - Jim Corbett (2N) - Mussoorie (2N) - Delhi",
      inclusions: ["4-Star Heritage & Nature Resorts", "Daily Buffet Breakfast & Candlelight Dinner", "Dedicated AC Sedan Cab", "Jim Corbett Jeep Safari Permit", "Honeymoon Cake & Flower Bed Decor (1 Night)"],
      exclusions: ["Boating charges at Naini Lake", "Monument entry tickets", "Personal tips & porter fees", "Anything not in inclusions"],
      overview: "A picture-perfect romantic getaway. Glide hand-in-hand in vintage shikaras across emerald Naini Lake, experience wild tiger safari in Corbett, and watch the misty sunset from George Everest peak in Mussoorie.",
      itinerary: [
        { day: "Day 1-2", title: "Delhi to Nainital - Lakes & Mall Road", detail: "Scenic drive from Delhi to Nainital. Enjoy romantic boat ride on Naini Lake, visit Naina Peak, Snow View Point, and shop at Tibetan Market." },
        { day: "Day 3-4", title: "Nainital to Jim Corbett Tiger Reserve", detail: "Drive down to Corbett. Check-in to riverside luxury resort. Embark on exhilarating morning 4x4 Jeep Safari in core tiger zone." },
        { day: "Day 5-6", title: "Corbett to Queen of Hills - Mussoorie", detail: "Drive to Mussoorie via Dehradun. Visit Kempty Falls, Camels Back Road, and enjoy sunset from Cloud's End with special candlelight dinner." },
        { day: "Day 7", title: "Mussoorie to Delhi Drop", detail: "Breakfast with Doon valley panorama, checkout, and return drive to Delhi with unforgettable memories." }
      ]
    },
    {
      id: "pkg-6",
      title: "Dharamshala, Bir Billing & Kasol Youth Trail",
      state: "Himachal",
      category: "Trekking",
      duration: "5 Days / 4 Nights",
      price: 13999,
      originalPrice: 18500,
      discount: "24% OFF",
      rating: 4.8,
      reviewsCount: 134,
      badge: "Trending",
      badgeColor: "emerald",
      heroImage: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1605649487212-47bdab064df7?auto=format&fit=crop&w=800&q=80"
      ],
      route: "Pathankot/Chandigarh - Dharamshala - McLeod Ganj - Bir Billing - Kasol - Parvati Valley",
      inclusions: ["Cozy Bohemian Hostels / Homestays", "Breakfast & Dinner", "Paragliding Pilot Session Assistance", "Kheerganga Trek Guide", "AC Tempo / SUV Transport"],
      exclusions: ["Paragliding jump ticket & GoPro video", "Cafe food bills", "Personal shopping", "Travel insurance"],
      overview: "The ultimate Himalayan youth backpacking circuit. Soak in Tibetan culture at Dalai Lama temple, soar through the skies from Asia's paragliding capital Bir Billing, and unwind by the gushing turquoise waters of Parvati river in Kasol.",
      itinerary: [
        { day: "Day 1", title: "Arrival in Dharamshala & McLeod Ganj", detail: "Check in to hillside stay. Visit Tsuglagkhang Temple (Dalai Lama Temple), Bhagsu waterfall, and chill at Shiva Cafe." },
        { day: "Day 2", title: "Triund Trek Day Hike or Kangra Fort", detail: "Panoramic day hike to Triund ridge with sheer views of snowcapped Dhauladhar wall. Evening Tibetan street food tasting." },
        { day: "Day 3", title: "Dharamshala to Bir Billing Paragliding Capital", detail: "Drive to Bir. Visit tea gardens and ancient monasteries. Take off from Billing (8,000 ft) for a 20-min tandem paragliding flight." },
        { day: "Day 4", title: "Bir to Kasol & Manikaran Gurudwara", detail: "Drive to Parvati Valley. Stroll through pine trails of Chalal village, visit holy hot springs at Manikaran Sahib, and camp by river." },
        { day: "Day 5", title: "Kasol Cafe Trail & Departure", detail: "Explore Israel-inspired bakeries, pick souvenirs at flea markets, and board evening return transfer." }
      ]
    },
    {
      id: "pkg-7",
      title: "Rishikesh White Water Rafting & Bungee Adventure",
      state: "Uttarakhand",
      category: "Adventure",
      duration: "3 Days / 2 Nights",
      price: 7999,
      originalPrice: 10500,
      discount: "23% OFF",
      rating: 4.9,
      reviewsCount: 310,
      badge: "Weekend Special",
      badgeColor: "amber",
      heroImage: "https://images.unsplash.com/photo-1544644181-1484b3fdfc62?auto=format&fit=crop&w=800&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1544644181-1484b3fdfc62?auto=format&fit=crop&w=800&q=80"
      ],
      route: "Delhi/Haridwar - Rishikesh - Shivpuri - Mohan Chatti",
      inclusions: ["Luxury Riverside Tents with Pool", "All 3 Meals (Breakfast, Lunch, Dinner)", "16km Ganga Rafting Grade III Rapids", "Cliff Jumping & Body Surfing", "Evening Bonfire with Live Acoustic Music"],
      exclusions: ["Bungee Jump / Flying Fox tickets", "Personal transfers to bungee site", "Liquor & personal expenses"],
      overview: "Inject pure adrenaline into your weekend. Battle raging Grade III+ rapids like Three Blind Mice and Roller Coaster on the holy Ganges, leap from India's highest 83m bungee platform, and party around a crackling riverside bonfire.",
      itinerary: [
        { day: "Day 1", title: "Arrival in Rishikesh & Riverside Camp Check-in", detail: "Arrive at luxury camp in Shivpuri. Welcome drinks, volleyball, sunset hike to secret waterfall, and musical bonfire dinner." },
        { day: "Day 2", title: "16 KM White Water Rafting & Cliff Jumping", detail: "Gear up with lifejackets and helmets. Ride the rapids of the Ganges, jump from 25-foot cliff, and body surf in glacier currents." },
        { day: "Day 3", title: "Bungee Jumping & Ganga Aarti Departure", detail: "Optional Bungee Jump at Mohan Chatti (83m). Witness mesmerizing Ganga Aarti at Triveni Ghat before your departure." }
      ]
    },
    {
      id: "pkg-8",
      title: "Jibhi & Tirthan Valley: Secret Pine Paradise",
      state: "Himachal",
      category: "Offbeat",
      duration: "4 Days / 3 Nights",
      price: 11999,
      originalPrice: 15500,
      discount: "22% OFF",
      rating: 4.9,
      reviewsCount: 88,
      badge: "Offbeat Gem",
      badgeColor: "emerald",
      heroImage: "https://images.unsplash.com/photo-1605649487212-47bdab064df7?auto=format&fit=crop&w=800&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1605649487212-47bdab064df7?auto=format&fit=crop&w=800&q=80"
      ],
      route: "Chandigarh - Aut - Banjar - Jibhi - Jalori Pass - Serolsar Lake - Shoja",
      inclusions: ["Handcrafted Cedar Wooden Treehouses / Cottages", "Organic Mountain Breakfast & Dinner", "Guided Trek to Serolsar Lake", "Local Sightseeing Vehicle", "Bonfire Evenings"],
      exclusions: ["Trout fishing permit", "Personal porter charges", "Meals outside itinerary"],
      overview: "Escape the tourist crowds to the untouched paradise of Banjar and Tirthan Valley. Stay in handcrafted wooden treehouses, listen to roaring crystal streams, trek through Jalori Pass to mythic Serolsar Lake, and fish for fresh Himalayan trout.",
      itinerary: [
        { day: "Day 1", title: "Chandigarh to Jibhi - Entering the Quiet Valley", detail: "Scenic drive through Mandi and Larji hydro dam tunnel. Check-in to traditional Kathkuni wooden cottage surrounded by pine trees." },
        { day: "Day 2", title: "Jibhi Waterfall & Hidden Stone Bridges", detail: "Hike through wooden walkways to Jibhi Waterfall, explore Mini Thailand rock pool, and relax with authentic Siddu at riverside cafe." },
        { day: "Day 3", title: "Jalori Pass (10,800 ft) & Serolsar Lake Trek", detail: "Drive to windy Jalori Pass. 5km gentle pine trek to sacred Serolsar Lake temple guarded by the mythological Budhi Nagin deity." },
        { day: "Day 4", title: "Shoja Hamlet & Return to Chandigarh", detail: "Morning birdwatching in Great Himalayan National Park buffer zone. Farewell lunch and drive back to Chandigarh." }
      ]
    }
  ],

  testimonials: [
    {
      name: "Rohit & Priya Sharma",
      location: "New Delhi",
      rating: 5,
      tour: "Magical Himachal (Shimla & Manali)",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80",
      review: "Our honeymoon in Manali was simply unforgettable! Himalayan Vistas arranged the most romantic cottage with snow views. Our driver Ramesh was courteous, knowledgeable, and always safe on mountain curves. 10/10 recommended!"
    },
    {
      name: "Col. Sanjeev Verma (Retd.)",
      location: "Chandigarh",
      rating: 5,
      tour: "Char Dham & Kedarnath Yatra",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80",
      review: "I took my elderly parents for Kedarnath & Badrinath. Himalayan Vistas took care of every single detail — comfortable stays, VIP darshan assistance, and hot organic meals. We felt like family throughout the yatra."
    },
    {
      name: "Aakash Patel & Squad",
      location: "Ahmedabad, Gujarat",
      rating: 5,
      tour: "Spiti Valley 4x4 Off-Road",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80",
      review: "Spiti was on our bucket list for years. The team arranged a monster 4x4 Scorpio with an experienced Spitian driver who knew every rock and detour. Camping at Chandratal under milky way stars was pure magic!"
    },
    {
      name: "Neha & Vikram Singhal",
      location: "Mumbai",
      rating: 5,
      tour: "Auli Snow & Chopta Trek",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80",
      review: "The skiing sessions in Auli and the sunrise from Chandrashila peak were breathtaking! Super transparent pricing with zero hidden charges. Will definitely book Kashmir/Ladakh with them next year!"
    }
  ],

  faqs: [
    {
      q: "What is the best time to visit Himachal Pradesh and Uttarakhand?",
      a: "Both states are year-round destinations! For snow lovers and skiing, December to February is peak. For pleasant weather and family escapes, March to June is ideal. For lush green mountain meadows, apple harvesting, and offbeat trips, September to November offers crisp blue skies."
    },
    {
      q: "Can you customize our tour package according to our dates & budget?",
      a: "Absolutely yes! 100% of our itineraries are fully customizable. You can choose your pickup location (Delhi, Chandigarh, Dehradun, etc.), hotel category (Budget, 3-Star, 4-Star Luxury, Heritage), vehicle type, and add specific activities like river rafting, paragliding, or camping."
    },
    {
      q: "How does the booking and payment process work?",
      a: "Booking is hassle-free! You only need to pay a 25% token advance to confirm your hotel and vehicle reservations. 50% is payable upon arrival on Day 1, and the remaining 25% can be settled mid-trip. We provide instant GST tax invoices and digital payment options (UPI, Netbanking, Credit Cards)."
    },
    {
      q: "Are your drivers experienced with high-altitude mountain terrain?",
      a: "Yes, without exception. All our drivers are mountain natives with valid commercial hill-driving licenses and years of experience navigating Rohtang Pass, Jalori Pass, Spiti dirt trails, and Uttarakhand ghat roads."
    },
    {
      q: "What is your cancellation and refund policy?",
      a: "We offer flexible cancellation: Free cancellation or reschedule up to 15 days before the departure date. In case of unexpected natural roadblocks, landslides, or official government closures, we immediately reschedule your tour or adjust payments towards alternative safe routes without cancellation penalties."
    }
  ],

  whyChooseUs: [
    {
      number: "01",
      title: "Himachal-Born Operators",
      description: "We are not a remote booking aggregator. Our main office is located right in Manali with branch desks in Shimla and Rishikesh."
    },
    {
      number: "02",
      title: "Zero Hidden Costs Guarantee",
      description: "Tolls, state tourist permits, driver food/night allowances, and vehicle taxes are all clearly outlined in your initial voucher."
    },
    {
      number: "03",
      title: "Tailormade For Indian Travelers",
      description: "We ensure pure veg / Jain food options, senior-citizen friendly pacing, child seats, and sanitized stays matching Indian family expectations."
    },
    {
      number: "04",
      title: "Real-Time Road & Weather Alerts",
      description: "Our local network continuously monitors Rohtang, Atal Tunnel, and Char Dham routes to ensure your safety ahead of weather warnings."
    }
  ]
};

// Export to window object for browser access
window.travelAgencyData = travelAgencyData;

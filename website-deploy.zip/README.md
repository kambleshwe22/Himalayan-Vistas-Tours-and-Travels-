# 🏔️ Himalayan Vistas Tours & Travels Website

A modern, high-converting, fully-responsive website designed specifically for a **Himachal & Uttarakhand Tour & Travel Agency**.

Built with semantic HTML5, modern Tailwind CSS, Lucide Icons, and clean vanilla JavaScript. It delivers a fast, award-winning look without the generic "AI-generated purple gradient" feel — featuring rich alpine forest greens, warm sunrise amber tones, and authentic mountain photography.

---

## 🌟 Key Features

1. **Brand Identity & Local Expertise**:
   - Tailored for a Himachal-based tour company offering both Himachal Pradesh and Uttarakhand (Devbhoomi) packages.
   - Highlights local mountain drivers, verified stays, zero hidden costs, and 24/7 travel desk support.

2. **Interactive Search & Filter Bar**:
   - Real-time search across destinations (Manali, Shimla, Spiti, Rishikesh, Kedarnath, Auli, Nainital).
   - Filter by trip duration (Short, Medium, Grand circuits) and budget ranges.

3. **Regional Destination Switcher**:
   - Interactive toggle between **Himachal Pradesh** (Manali, Spiti, Shimla, Dharamshala, Kasol) and **Uttarakhand** (Rishikesh, Kedarnath, Auli, Nainital, Jim Corbett).

4. **Curated Package Cards with Live Category Filtering**:
   - Filter by: *All, Himachal Only, Uttarakhand Only, Family, Honeymoon, Adventure, Spiritual, Offbeat*.
   - Realistic INR (₹) pricing, discount tags, duration pills, ratings, route overviews, and inclusion badges.

5. **Day-by-Day Itinerary Modal**:
   - Click "Itinerary" on any package to see a detailed day-wise breakdown, route map, complete inclusions, and exclusions.

6. **Interactive Reservation & Booking Calculator**:
   - Modal booking form that dynamically calculates total estimated cost based on the package and number of adults/children.
   - One-click **WhatsApp Integration** that formats and sends the exact booking inquiry directly to your WhatsApp business number.

7. **Mobile-First & Fully Responsive**:
   - Optimized for desktop, iPad/tablets, and mobile smartphones with a sleek slide-over mobile navigation drawer.

---

## 📁 Project Structure

```text
e:\shweta prajoect\
│
├── index.html         # Main web page structure & layout
├── css/
│   └── style.css      # Alpine color schemes, animations, glassmorphism, scrollbars
├── js/
│   ├── data.js        # MASTER DATA FILE: edit your business name, packages, prices, reviews
│   └── app.js         # Interactive application logic (filters, search, modals, WhatsApp)
└── README.md          # Complete documentation & customization guide
```

---

## 🛠️ How to Customize (Easy 5-Minute Setup)

All the information on this website is stored in a single, clean file: [`js/data.js`](file:///e:/shweta%20prajoect/js/data.js). You do not need to touch complicated HTML to update your agency details.

### 1. Update Business Name & Contact Info
Open `js/data.js` and edit the `business` block:
```javascript
business: {
  name: "Your Agency Name",
  tagline: "Your Slogan Here",
  location: "Your Physical Office Address, Himachal Pradesh",
  contact: {
    phone: "+91 98765 43210",          // Your calling number
    whatsapp: "919876543210",          // WhatsApp number (include country code without +)
    email: "info@yourwebsite.com",     // Your booking email
  }
}
```

### 2. Add or Edit Tour Packages & Prices
In `js/data.js`, look for the `packages` array:
```javascript
{
  id: "pkg-custom",
  title: "Shimla Kullu Manali Volvo Tour",
  state: "Himachal",                   // "Himachal" or "Uttarakhand"
  category: "Family",                  // "Family", "Honeymoon", "Adventure", "Spiritual", etc.
  duration: "5 Days / 4 Nights",
  price: 14999,                        // Current price in ₹
  originalPrice: 19999,                // Strikethrough price in ₹
  discount: "25% OFF",
  badge: "Best Seller",
  heroImage: "https://your-image-url.com/photo.jpg",
  route: "Delhi - Shimla - Manali - Delhi",
  inclusions: ["3-Star Hotels", "Volvo Tickets", "Breakfast & Dinner", "Cab Sightseeing"],
  exclusions: ["Airfare", "Personal Expenses"],
  itinerary: [
    { day: "Day 1", title: "Delhi to Shimla", detail: "Overnight Volvo journey..." },
    { day: "Day 2", title: "Shimla & Kufri", detail: "Sightseeing at Ridge..." }
  ]
}
```

### 3. Change Colors & Theme
If you ever want to adjust colors, open `css/style.css` and tweak the root variables:
- Primary Forest Green: `#0c3327`
- Accent Amber/Gold: `#d97706`
- Surface: `#fafaf9`

---

## 🚀 How to Run & Preview Locally

### Option A: Double-Click
Simply double-click [`index.html`](file:///e:/shweta%20prajoect/index.html) to open it directly in Google Chrome, Microsoft Edge, or Firefox.

### Option B: Local Live Server (Node.js / npx)
In your terminal, run:
```powershell
npx serve .
```
Or with Python:
```powershell
python -m http.server 8000
```
Then visit `http://localhost:8000` or the port displayed.

---

## 🌐 Deploy to Web (Free Hosting Options)
- **Netlify**: Drag and drop the `shweta prajoect` folder into [Netlify Drop](https://app.netlify.com/drop).
- **Vercel**: Run `npx vercel` in this folder.
- **GitHub Pages**: Push this repo to GitHub and enable Pages in repository settings.

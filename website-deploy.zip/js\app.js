/**
 * Himalayan Vistas Tours & Travels - Core Application Engine
 * Handles dynamic rendering, filters, search, modals, booking math, and WhatsApp automation.
 */

const FALLBACK_MOUNTAIN_IMG = "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?auto=format&fit=crop&w=800&q=80";

document.addEventListener("DOMContentLoaded", () => {
  initApp();
});

let currentFilter = "all";
let activeDestinationTab = "himachal";
let selectedPackageForBooking = null;

function initApp() {
  renderCompanyInfo();
  renderDestinations();
  renderPackages();
  renderFilterTabs();
  renderTestimonials();
  renderFaqs();
  setupEventListeners();
  if (window.lucide) {
    lucide.createIcons();
  }
}

/**
 * 1. Populate dynamic company brand information across the page
 */
function renderCompanyInfo() {
  const data = window.travelAgencyData;
  if (!data) return;

  const b = data.business;
  document.querySelectorAll(".dyn-biz-name").forEach(el => el.textContent = b.name);
  document.querySelectorAll(".dyn-biz-tagline").forEach(el => el.textContent = b.tagline);
  document.querySelectorAll(".dyn-biz-phone").forEach(el => {
    el.textContent = b.contact.phone;
    el.href = `tel:${b.contact.phone.replace(/[\s-]/g, '')}`;
  });
  document.querySelectorAll(".dyn-biz-email").forEach(el => {
    el.textContent = b.contact.email;
    el.href = `mailto:${b.contact.email}`;
  });
  document.querySelectorAll(".dyn-biz-address").forEach(el => el.textContent = b.location);
  
  const waBtn = document.getElementById("floating-whatsapp-btn");
  if (waBtn) {
    waBtn.href = `https://wa.me/${b.contact.whatsapp}?text=${encodeURIComponent("Hello Himalayan Vistas! I want to inquire about your Himachal and Uttarakhand tour packages.")}`;
  }
}

/**
 * 2. Destinations Showcase (Himachal vs Uttarakhand)
 */
function renderDestinations() {
  const destContainer = document.getElementById("destinations-container");
  if (!destContainer || !window.travelAgencyData) return;

  const currentDest = window.travelAgencyData.destinations.find(d => d.id === activeDestinationTab);
  if (!currentDest) return;

  destContainer.innerHTML = `
    <div class="relative rounded-3xl overflow-hidden shadow-2xl mb-8 border border-slate-200/60 bg-slate-900">
      <img 
        src="${currentDest.bgImage}" 
        alt="${currentDest.state}" 
        onerror="this.onerror=null; this.src='${FALLBACK_MOUNTAIN_IMG}';" 
        class="w-full h-72 md:h-96 object-cover" 
      />
      <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/60 to-transparent flex flex-col justify-end p-6 md:p-10 text-white">
        <span class="inline-block px-3 py-1 bg-amber-500/90 text-xs font-bold uppercase tracking-wider rounded-full w-max mb-3 backdrop-blur-sm">Featured Region</span>
        <h3 class="text-3xl md:text-5xl font-extrabold font-serif-heading mb-2">${currentDest.state}</h3>
        <p class="text-slate-200 text-sm md:text-lg max-w-2xl font-light">${currentDest.tagline} — ${currentDest.description}</p>
      </div>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
      ${currentDest.spots.map(spot => `
        <div class="group relative rounded-2xl overflow-hidden shadow-md bg-white border border-slate-100 flex flex-col hover:shadow-xl transition-all duration-300">
          <div class="h-44 overflow-hidden relative bg-slate-100">
            <img 
              src="${spot.image}" 
              alt="${spot.name}" 
              onerror="this.onerror=null; this.src='${FALLBACK_MOUNTAIN_IMG}';" 
              class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
              loading="lazy"
            />
            <span class="absolute top-3 left-3 bg-slate-900/80 backdrop-blur-md text-white text-[11px] font-medium px-2.5 py-1 rounded-md">
              ${spot.tag}
            </span>
          </div>
          <div class="p-4 flex-1 flex flex-col justify-between">
            <div>
              <h4 class="font-bold text-slate-800 text-base mb-1 group-hover:text-emerald-800 transition-colors">${spot.name}</h4>
              <p class="text-xs text-slate-500 line-clamp-2 leading-relaxed">${spot.desc}</p>
            </div>
            <button onclick="filterByLocationKeyword('${spot.name.split(' ')[0]}')" class="mt-3 text-xs font-semibold text-emerald-800 hover:text-emerald-950 flex items-center gap-1 cursor-pointer">
              <span>View Packages</span>
              <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
            </button>
          </div>
        </div>
      `).join("")}
    </div>
  `;

  if (window.lucide) lucide.createIcons();
}

/**
 * Switch state tab (Himachal <-> Uttarakhand)
 */
window.switchDestinationTab = function(stateId) {
  activeDestinationTab = stateId;
  document.querySelectorAll(".dest-tab-btn").forEach(btn => {
    if (btn.dataset.state === stateId) {
      btn.className = "dest-tab-btn px-6 py-2.5 rounded-full text-sm font-semibold transition-all bg-[#0c3327] text-white shadow-md cursor-pointer";
    } else {
      btn.className = "dest-tab-btn px-6 py-2.5 rounded-full text-sm font-semibold transition-all bg-white text-slate-600 border border-slate-200 hover:bg-slate-50 cursor-pointer";
    }
  });
  renderDestinations();
};

/**
 * 3. Filter Tabs Setup
 */
function renderFilterTabs() {
  const categories = [
    { key: "all", label: "All Packages" },
    { key: "Himachal", label: "Himachal Only" },
    { key: "Uttarakhand", label: "Uttarakhand Only" },
    { key: "Family", label: "Family Delights" },
    { key: "Honeymoon", label: "Honeymoon & Couples" },
    { key: "Adventure", label: "Adventure & Treks" },
    { key: "Spiritual", label: "Spiritual & Yatra" },
    { key: "Offbeat", label: "Offbeat & Hidden Gems" }
  ];

  const container = document.getElementById("package-filters");
  if (!container) return;

  container.innerHTML = categories.map(cat => `
    <button 
      onclick="setFilter('${cat.key}')" 
      class="tag-pill px-4 py-2 rounded-full text-xs sm:text-sm font-medium border border-slate-200 bg-white text-slate-700 hover:bg-slate-100 whitespace-nowrap cursor-pointer ${currentFilter === cat.key ? 'active' : ''}">
      ${cat.label}
    </button>
  `).join("");
}

window.setFilter = function(filterKey) {
  currentFilter = filterKey;
  renderFilterTabs();
  renderPackages();
};

/**
 * 4. Render Tour Packages
 */
function renderPackages(customList = null) {
  const container = document.getElementById("packages-grid");
  if (!container || !window.travelAgencyData) return;

  let pkgs = customList || window.travelAgencyData.packages;

  if (!customList && currentFilter !== "all") {
    pkgs = pkgs.filter(p => p.state === currentFilter || p.category === currentFilter);
  }

  if (pkgs.length === 0) {
    container.innerHTML = `
      <div class="col-span-full py-16 text-center bg-white rounded-3xl border border-dashed border-slate-200 p-8">
        <i data-lucide="map-pin-off" class="w-12 h-12 text-slate-300 mx-auto mb-3"></i>
        <h4 class="text-xl font-bold text-slate-700 mb-1">No Matching Packages Found</h4>
        <p class="text-slate-500 text-sm max-w-md mx-auto mb-5">We couldn't find a package matching your exact filters. Contact our Himalayan travel desk to create a tailored custom itinerary!</p>
        <button onclick="setFilter('all')" class="px-5 py-2.5 rounded-full bg-[#0c3327] text-white text-xs font-semibold hover:bg-emerald-900 transition-colors cursor-pointer">
          Reset All Filters
        </button>
      </div>
    `;
    if (window.lucide) lucide.createIcons();
    return;
  }

  container.innerHTML = pkgs.map(p => {
    const badgeColors = {
      emerald: "bg-emerald-50 text-emerald-800 border-emerald-200",
      amber: "bg-amber-50 text-amber-800 border-amber-200",
      sky: "bg-sky-50 text-sky-800 border-sky-200",
      rose: "bg-rose-50 text-rose-800 border-rose-200"
    };
    const badgeClass = badgeColors[p.badgeColor] || "bg-emerald-50 text-emerald-800 border-emerald-200";

    return `
      <div class="travel-card bg-white rounded-3xl border border-slate-100 overflow-hidden shadow-sm hover:shadow-xl flex flex-col group">
        <!-- Image & Tags -->
        <div class="img-zoom-container relative h-60 w-full overflow-hidden bg-slate-900">
          <img 
            src="${p.heroImage}" 
            alt="${p.title}" 
            onerror="this.onerror=null; this.src='${FALLBACK_MOUNTAIN_IMG}';" 
            class="w-full h-full object-cover" 
            loading="lazy" 
          />
          <div class="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-black/20"></div>
          
          <!-- Top Badges -->
          <div class="absolute top-4 left-4 flex gap-2">
            <span class="text-xs font-semibold px-3 py-1 rounded-full border backdrop-blur-md shadow-sm ${badgeClass}">
              ${p.badge}
            </span>
            <span class="text-xs font-semibold px-3 py-1 rounded-full bg-slate-900/80 text-white backdrop-blur-md">
              ${p.state}
            </span>
          </div>

          <!-- Duration Pill -->
          <div class="absolute bottom-3 left-4 flex items-center gap-1.5 text-white text-xs font-medium bg-black/40 backdrop-blur-md px-3 py-1 rounded-full">
            <i data-lucide="clock" class="w-3.5 h-3.5 text-amber-400"></i>
            <span>${p.duration}</span>
          </div>

          <!-- Rating -->
          <div class="absolute bottom-3 right-4 flex items-center gap-1 text-white text-xs font-bold bg-black/40 backdrop-blur-md px-2.5 py-1 rounded-full">
            <i data-lucide="star" class="w-3.5 h-3.5 text-amber-400 fill-amber-400"></i>
            <span>${p.rating}</span>
            <span class="text-slate-300 font-normal">(${p.reviewsCount})</span>
          </div>
        </div>

        <!-- Content Body -->
        <div class="p-6 flex-1 flex flex-col justify-between">
          <div>
            <h3 class="font-bold text-slate-800 text-lg leading-snug mb-2 group-hover:text-emerald-800 transition-colors">
              ${p.title}
            </h3>
            
            <p class="text-xs text-slate-500 mb-4 line-clamp-2">
              <span class="font-semibold text-slate-700">Route:</span> ${p.route}
            </p>

            <div class="grid grid-cols-2 gap-2 mb-4 pb-4 border-b border-slate-100 text-[11px] text-slate-600">
              <div class="flex items-center gap-1.5 truncate">
                <i data-lucide="hotel" class="w-3.5 h-3.5 text-emerald-700 flex-shrink-0"></i>
                <span class="truncate">Verified Hotels/Camps</span>
              </div>
              <div class="flex items-center gap-1.5 truncate">
                <i data-lucide="car" class="w-3.5 h-3.5 text-emerald-700 flex-shrink-0"></i>
                <span class="truncate">Private Hill Transport</span>
              </div>
              <div class="flex items-center gap-1.5 truncate">
                <i data-lucide="utensils" class="w-3.5 h-3.5 text-emerald-700 flex-shrink-0"></i>
                <span class="truncate">Meals Included</span>
              </div>
              <div class="flex items-center gap-1.5 truncate">
                <i data-lucide="map" class="w-3.5 h-3.5 text-emerald-700 flex-shrink-0"></i>
                <span class="truncate">Sightseeing Guide</span>
              </div>
            </div>
          </div>

          <div>
            <div class="flex items-baseline justify-between mb-4">
              <div>
                <span class="text-xs text-slate-400 line-through">₹${p.originalPrice.toLocaleString('en-IN')}</span>
                <div class="flex items-baseline gap-1">
                  <span class="text-2xl font-black text-slate-900">₹${p.price.toLocaleString('en-IN')}</span>
                  <span class="text-xs text-slate-500 font-medium">/ person</span>
                </div>
              </div>
              <span class="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-100">
                ${p.discount}
              </span>
            </div>

            <div class="grid grid-cols-2 gap-2.5">
              <button 
                onclick="openPackageDetails('${p.id}')" 
                class="w-full py-2.5 rounded-xl border border-slate-200 text-slate-700 text-xs font-semibold hover:border-slate-800 hover:text-slate-900 transition-colors flex items-center justify-center gap-1 cursor-pointer">
                <i data-lucide="info" class="w-3.5 h-3.5"></i>
                <span>Itinerary</span>
              </button>

              <button 
                onclick="openBookingModal('${p.id}')" 
                class="w-full py-2.5 rounded-xl bg-[#0c3327] hover:bg-emerald-900 text-white text-xs font-semibold transition-all shadow-sm flex items-center justify-center gap-1 cursor-pointer">
                <span>Book Now</span>
                <i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }).join("");

  if (window.lucide) lucide.createIcons();
}

/**
 * 5. Search & Filters Action
 */
window.handleSearch = function(event) {
  event.preventDefault();
  const dest = document.getElementById("search-destination").value.toLowerCase();
  const duration = document.getElementById("search-duration").value;
  const budget = document.getElementById("search-budget").value;

  let results = window.travelAgencyData.packages.filter(pkg => {
    let matchDest = true;
    if (dest) {
      matchDest = pkg.state.toLowerCase().includes(dest) ||
                  pkg.title.toLowerCase().includes(dest) ||
                  pkg.route.toLowerCase().includes(dest);
    }

    let matchDuration = true;
    if (duration) {
      const days = parseInt(pkg.duration.split(" ")[0]);
      if (duration === "short") matchDuration = days <= 4;
      else if (duration === "medium") matchDuration = days >= 5 && days <= 7;
      else if (duration === "long") matchDuration = days >= 8;
    }

    let matchBudget = true;
    if (budget) {
      if (budget === "budget") matchBudget = pkg.price <= 15000;
      else if (budget === "mid") matchBudget = pkg.price > 15000 && pkg.price <= 25000;
      else if (budget === "luxury") matchBudget = pkg.price > 25000;
    }

    return matchDest && matchDuration && matchBudget;
  });

  renderPackages(results);

  const el = document.getElementById("packages-section");
  if (el) el.scrollIntoView({ behavior: "smooth" });
  
  showToast(`Found ${results.length} package(s) matching your criteria.`);
};

window.filterByLocationKeyword = function(keyword) {
  const filtered = window.travelAgencyData.packages.filter(p => 
    p.title.toLowerCase().includes(keyword.toLowerCase()) || 
    p.route.toLowerCase().includes(keyword.toLowerCase()) ||
    p.state.toLowerCase().includes(keyword.toLowerCase())
  );
  renderPackages(filtered.length > 0 ? filtered : null);
  const el = document.getElementById("packages-section");
  if (el) el.scrollIntoView({ behavior: "smooth" });
};

/**
 * 6. Package Details Modal
 */
window.openPackageDetails = function(pkgId) {
  const pkg = window.travelAgencyData.packages.find(p => p.id === pkgId);
  if (!pkg) return;

  const modal = document.getElementById("details-modal");
  const modalContent = document.getElementById("details-modal-content");
  if (!modal || !modalContent) return;

  modalContent.innerHTML = `
    <div class="relative h-64 md:h-80 w-full overflow-hidden rounded-t-3xl bg-slate-900">
      <img 
        src="${pkg.heroImage}" 
        alt="${pkg.title}" 
        onerror="this.onerror=null; this.src='${FALLBACK_MOUNTAIN_IMG}';" 
        class="w-full h-full object-cover" 
      />
      <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/40 to-transparent"></div>
      <button onclick="closeDetailsModal()" class="absolute top-4 right-4 w-10 h-10 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-black/80 transition-colors backdrop-blur-md cursor-pointer">
        <i data-lucide="x" class="w-5 h-5"></i>
      </button>

      <div class="absolute bottom-6 left-6 right-6 text-white">
        <div class="flex items-center gap-2 mb-2">
          <span class="px-3 py-1 bg-amber-500 text-xs font-bold rounded-full uppercase tracking-wider">${pkg.badge}</span>
          <span class="px-3 py-1 bg-white/20 backdrop-blur-md text-xs font-medium rounded-full">${pkg.duration}</span>
        </div>
        <h2 class="text-2xl md:text-3xl font-extrabold font-serif-heading">${pkg.title}</h2>
        <p class="text-xs md:text-sm text-slate-300 flex items-center gap-1.5 mt-1">
          <i data-lucide="map-pin" class="w-4 h-4 text-emerald-400"></i>
          <span>${pkg.route}</span>
        </p>
      </div>
    </div>

    <div class="p-6 md:p-8 space-y-8 max-h-[65vh] overflow-y-auto">
      <div class="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-100 text-center">
        <div>
          <span class="text-xs text-slate-400 block">Starting Price</span>
          <span class="text-xl font-black text-slate-900">₹${pkg.price.toLocaleString('en-IN')}</span>
          <span class="text-[10px] text-slate-500 block">per person</span>
        </div>
        <div>
          <span class="text-xs text-slate-400 block">Duration</span>
          <span class="text-lg font-bold text-slate-800">${pkg.duration}</span>
          <span class="text-[10px] text-slate-500 block">Tailored Pacing</span>
        </div>
        <div>
          <span class="text-xs text-slate-400 block">Customer Rating</span>
          <div class="flex items-center justify-center gap-1 text-lg font-bold text-slate-800">
            <i data-lucide="star" class="w-4 h-4 text-amber-500 fill-amber-500"></i>
            <span>${pkg.rating} / 5</span>
          </div>
          <span class="text-[10px] text-slate-500 block">${pkg.reviewsCount} Verified Reviews</span>
        </div>
        <div>
          <span class="text-xs text-slate-400 block">Ideal For</span>
          <span class="text-lg font-bold text-emerald-800">${pkg.category}</span>
          <span class="text-[10px] text-slate-500 block">${pkg.state} Tours</span>
        </div>
      </div>

      <div>
        <h3 class="text-lg font-bold text-slate-800 mb-2 flex items-center gap-2">
          <i data-lucide="sparkles" class="w-5 h-5 text-amber-500"></i>
          <span>Trip Overview</span>
        </h3>
        <p class="text-slate-600 text-sm leading-relaxed">${pkg.overview}</p>
      </div>

      <div>
        <h3 class="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
          <i data-lucide="calendar" class="w-5 h-5 text-emerald-700"></i>
          <span>Day-by-Day Itinerary</span>
        </h3>
        <div class="space-y-4">
          ${pkg.itinerary.map((dayItem, idx) => `
            <div class="itinerary-step">
              <div class="absolute left-0 top-0.5 w-4 h-4 rounded-full bg-emerald-600 border-2 border-white shadow-sm"></div>
              <div class="bg-white rounded-xl p-4 border border-slate-200/80 shadow-sm">
                <div class="flex items-center gap-2 mb-1">
                  <span class="px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 font-bold text-xs">${dayItem.day}</span>
                  <h4 class="font-bold text-slate-800 text-sm">${dayItem.title}</h4>
                </div>
                <p class="text-xs text-slate-600 leading-relaxed mt-1">${dayItem.detail}</p>
              </div>
            </div>
          `).join("")}
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="p-5 rounded-2xl bg-emerald-50/50 border border-emerald-100">
          <h4 class="font-bold text-emerald-950 text-sm mb-3 flex items-center gap-1.5">
            <i data-lucide="check-circle" class="w-4 h-4 text-emerald-600"></i>
            <span>Package Inclusions</span>
          </h4>
          <ul class="space-y-2 text-xs text-slate-700">
            ${pkg.inclusions.map(inc => `
              <li class="flex items-start gap-2">
                <i data-lucide="check" class="w-3.5 h-3.5 text-emerald-600 flex-shrink-0 mt-0.5"></i>
                <span>${inc}</span>
              </li>
            `).join("")}
          </ul>
        </div>

        <div class="p-5 rounded-2xl bg-rose-50/50 border border-rose-100">
          <h4 class="font-bold text-rose-950 text-sm mb-3 flex items-center gap-1.5">
            <i data-lucide="x-circle" class="w-4 h-4 text-rose-600"></i>
            <span>Package Exclusions</span>
          </h4>
          <ul class="space-y-2 text-xs text-slate-700">
            ${pkg.exclusions.map(exc => `
              <li class="flex items-start gap-2">
                <i data-lucide="minus" class="w-3.5 h-3.5 text-rose-500 flex-shrink-0 mt-0.5"></i>
                <span>${exc}</span>
              </li>
            `).join("")}
          </ul>
        </div>
      </div>
    </div>

    <div class="p-5 md:p-6 bg-slate-50 border-t border-slate-200/80 rounded-b-3xl flex flex-col sm:flex-row items-center justify-between gap-4">
      <div>
        <span class="text-xs text-slate-400 block">Starting From</span>
        <div class="flex items-baseline gap-1">
          <span class="text-2xl font-black text-slate-900">₹${pkg.price.toLocaleString('en-IN')}</span>
          <span class="text-xs text-slate-500">/ person (All taxes incl.)</span>
        </div>
      </div>

      <div class="flex items-center gap-3 w-full sm:w-auto">
        <a 
          href="https://wa.me/${window.travelAgencyData.business.contact.whatsapp}?text=${encodeURIComponent(`Hi! I am interested in booking the '${pkg.title}' (${pkg.duration}) starting at ₹${pkg.price}. Please share details.`)}" 
          target="_blank"
          class="flex-1 sm:flex-initial px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-sm transition-all">
          <i data-lucide="message-circle" class="w-4 h-4"></i>
          <span>Ask on WhatsApp</span>
        </a>

        <button 
          onclick="closeDetailsModal(); openBookingModal('${pkg.id}')"
          class="flex-1 sm:flex-initial px-6 py-3 rounded-xl bg-[#0c3327] hover:bg-emerald-950 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md transition-all cursor-pointer">
          <span>Book This Package</span>
          <i data-lucide="arrow-right" class="w-4 h-4"></i>
        </button>
      </div>
    </div>
  `;

  modal.classList.remove("hidden");
  modal.classList.add("flex");
  document.body.style.overflow = "hidden";
  if (window.lucide) lucide.createIcons();
};

window.closeDetailsModal = function() {
  const modal = document.getElementById("details-modal");
  if (!modal) return;
  modal.classList.add("hidden");
  modal.classList.remove("flex");
  document.body.style.overflow = "auto";
};

/**
 * 7. Booking & Reservation Modal
 */
window.openBookingModal = function(pkgId = null) {
  const pkgs = window.travelAgencyData.packages;
  const modal = document.getElementById("booking-modal");
  if (!modal) return;

  const selectEl = document.getElementById("booking-package-select");
  if (selectEl) {
    selectEl.innerHTML = pkgs.map(p => `
      <option value="${p.id}" ${pkgId === p.id ? 'selected' : ''}>
        ${p.title} (${p.duration}) - ₹${p.price.toLocaleString('en-IN')}/person
      </option>
    `).join("");
  }

  updateBookingPriceEstimate();

  modal.classList.remove("hidden");
  modal.classList.add("flex");
  document.body.style.overflow = "hidden";
  if (window.lucide) lucide.createIcons();
};

window.closeBookingModal = function() {
  const modal = document.getElementById("booking-modal");
  if (!modal) return;
  modal.classList.add("hidden");
  modal.classList.remove("flex");
  document.body.style.overflow = "auto";
};

window.updateBookingPriceEstimate = function() {
  const selectEl = document.getElementById("booking-package-select");
  const adultsEl = document.getElementById("booking-adults");
  const childrenEl = document.getElementById("booking-children");
  const displayEl = document.getElementById("booking-total-display");
  if (!selectEl || !adultsEl || !displayEl) return;

  const pkgId = selectEl.value;
  const pkg = window.travelAgencyData.packages.find(p => p.id === pkgId);
  if (!pkg) return;

  const adults = parseInt(adultsEl.value) || 1;
  const children = parseInt(childrenEl ? childrenEl.value : 0) || 0;

  const total = (adults * pkg.price) + (children * Math.round(pkg.price * 0.6));
  displayEl.textContent = `₹${total.toLocaleString('en-IN')}`;
};

/**
 * Submit Booking
 */
window.handleBookingSubmit = function(event) {
  event.preventDefault();
  const selectEl = document.getElementById("booking-package-select");
  const pkg = window.travelAgencyData.packages.find(p => p.id === selectEl.value);
  if (!pkg) return;

  const name = document.getElementById("booking-name").value;
  const phone = document.getElementById("booking-phone").value;
  const date = document.getElementById("booking-date").value;
  const adults = document.getElementById("booking-adults").value;
  const children = document.getElementById("booking-children").value;
  const notes = document.getElementById("booking-notes").value;
  const totalStr = document.getElementById("booking-total-display").textContent;

  const bookingRef = "HV-" + Math.floor(100000 + Math.random() * 900000);

  closeBookingModal();

  const successModal = document.getElementById("success-modal");
  const detailsContainer = document.getElementById("success-details");
  if (successModal && detailsContainer) {
    detailsContainer.innerHTML = `
      <div class="p-4 bg-emerald-50 rounded-2xl border border-emerald-100 text-left space-y-2 text-xs text-slate-700">
        <div class="flex justify-between border-b border-emerald-100 pb-2">
          <span class="text-slate-500">Booking Reference:</span>
          <span class="font-bold text-emerald-900">${bookingRef}</span>
        </div>
        <div class="flex justify-between border-b border-emerald-100 pb-2">
          <span class="text-slate-500">Selected Package:</span>
          <span class="font-bold text-slate-900 text-right">${pkg.title}</span>
        </div>
        <div class="flex justify-between border-b border-emerald-100 pb-2">
          <span class="text-slate-500">Travel Date:</span>
          <span class="font-semibold text-slate-800">${date || 'Flexible'}</span>
        </div>
        <div class="flex justify-between border-b border-emerald-100 pb-2">
          <span class="text-slate-500">Travelers:</span>
          <span class="font-semibold text-slate-800">${adults} Adults, ${children} Children</span>
        </div>
        <div class="flex justify-between pt-1 text-sm font-bold">
          <span class="text-slate-900">Estimated Total:</span>
          <span class="text-emerald-800">${totalStr}</span>
        </div>
      </div>
    `;

    const waShareBtn = document.getElementById("success-whatsapp-share");
    if (waShareBtn) {
      const waText = `*Himalayan Tour Reservation Request*
Booking Ref: ${bookingRef}
Package: ${pkg.title} (${pkg.duration})
Name: ${name}
Phone: ${phone}
Travel Date: ${date}
Guests: ${adults} Adults, ${children} Children
Estimated Total: ${totalStr}
Notes: ${notes || 'None'}

Please confirm hotel availability and driver assignment.`;

      waShareBtn.href = `https://wa.me/${window.travelAgencyData.business.contact.whatsapp}?text=${encodeURIComponent(waText)}`;
    }

    successModal.classList.remove("hidden");
    successModal.classList.add("flex");
    if (window.lucide) lucide.createIcons();
  }
};

window.closeSuccessModal = function() {
  const modal = document.getElementById("success-modal");
  if (!modal) return;
  modal.classList.add("hidden");
  modal.classList.remove("flex");
  document.body.style.overflow = "auto";
};

/**
 * 8. Render Testimonials
 */
function renderTestimonials() {
  const container = document.getElementById("testimonials-grid");
  if (!container || !window.travelAgencyData) return;

  const list = window.travelAgencyData.testimonials;
  container.innerHTML = list.map(t => `
    <div class="p-6 md:p-8 rounded-3xl bg-white border border-slate-100 shadow-sm flex flex-col justify-between hover:shadow-lg transition-all duration-300">
      <div>
        <div class="flex items-center gap-1 text-amber-400 mb-4">
          ${Array(t.rating).fill('<i data-lucide="star" class="w-4 h-4 fill-amber-400"></i>').join("")}
        </div>
        <p class="text-slate-600 text-sm italic leading-relaxed mb-6">"${t.review}"</p>
      </div>

      <div class="flex items-center gap-4 pt-4 border-t border-slate-100">
        <img 
          src="${t.avatar}" 
          alt="${t.name}" 
          onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80';" 
          class="w-12 h-12 rounded-full object-cover ring-2 ring-emerald-700/20" 
          loading="lazy"
        />
        <div>
          <h4 class="font-bold text-slate-900 text-sm">${t.name}</h4>
          <span class="text-xs text-slate-400">${t.location} • <span class="text-emerald-700 font-medium">${t.tour}</span></span>
        </div>
      </div>
    </div>
  `).join("");

  if (window.lucide) lucide.createIcons();
}

/**
 * 9. Render FAQs with Accordion Logic
 */
function renderFaqs() {
  const container = document.getElementById("faqs-container");
  if (!container || !window.travelAgencyData) return;

  const faqs = window.travelAgencyData.faqs;
  container.innerHTML = faqs.map((f, i) => `
    <div class="faq-item rounded-2xl bg-white border border-slate-200/80 overflow-hidden shadow-sm transition-all">
      <button 
        onclick="toggleFaq(${i})" 
        class="w-full p-5 text-left font-bold text-slate-800 text-sm md:text-base flex items-center justify-between gap-4 hover:bg-slate-50 transition-colors cursor-pointer">
        <span>${f.q}</span>
        <i data-lucide="chevron-down" id="faq-icon-${i}" class="w-4 h-4 text-slate-400 transition-transform duration-300"></i>
      </button>
      <div id="faq-ans-${i}" class="hidden p-5 pt-0 text-xs md:text-sm text-slate-600 leading-relaxed border-t border-slate-100">
        ${f.a}
      </div>
    </div>
  `).join("");

  if (window.lucide) lucide.createIcons();
}

window.toggleFaq = function(index) {
  const ans = document.getElementById(`faq-ans-${index}`);
  const icon = document.getElementById(`faq-icon-${index}`);
  if (!ans || !icon) return;

  const isHidden = ans.classList.contains("hidden");
  if (isHidden) {
    ans.classList.remove("hidden");
    icon.classList.add("rotate-180");
  } else {
    ans.classList.add("hidden");
    icon.classList.remove("rotate-180");
  }
};

/**
 * 10. Quick Toast Helper
 */
function showToast(msg) {
  let toast = document.getElementById("toast-notification");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "toast-notification";
    toast.className = "fixed bottom-24 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-full bg-slate-900 text-white text-xs font-semibold shadow-2xl flex items-center gap-2 pointer-events-none opacity-0 transition-opacity duration-300";
    document.body.appendChild(toast);
  }
  toast.innerHTML = `<i data-lucide="info" class="w-4 h-4 text-emerald-400"></i> <span>${msg}</span>`;
  if (window.lucide) lucide.createIcons();
  toast.classList.remove("opacity-0");
  toast.classList.add("opacity-100");

  setTimeout(() => {
    toast.classList.remove("opacity-100");
    toast.classList.add("opacity-0");
  }, 3200);
}

/**
 * 11. Event Listeners
 */
function setupEventListeners() {
  const mobileToggle = document.getElementById("mobile-menu-toggle");
  const mobileDrawer = document.getElementById("mobile-drawer");
  const mobileClose = document.getElementById("mobile-drawer-close");

  if (mobileToggle && mobileDrawer) {
    mobileToggle.addEventListener("click", () => {
      mobileDrawer.classList.remove("translate-x-full");
    });
  }
  if (mobileClose && mobileDrawer) {
    mobileClose.addEventListener("click", () => {
      mobileDrawer.classList.add("translate-x-full");
    });
  }

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      closeDetailsModal();
      closeBookingModal();
      closeSuccessModal();
      if (mobileDrawer) mobileDrawer.classList.add("translate-x-full");
    }
  });

  const customForm = document.getElementById("custom-trip-form");
  if (customForm) {
    customForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const dest = document.getElementById("custom-dest").value;
      const phone = document.getElementById("custom-phone").value;
      const days = document.getElementById("custom-days").value;

      const waMsg = `Hi Himalayan Vistas, I want a customized tour plan for *${dest}* for around *${days} days*. My contact is ${phone}. Please call me back.`;
      window.open(`https://wa.me/${window.travelAgencyData.business.contact.whatsapp}?text=${encodeURIComponent(waMsg)}`, "_blank");
      showToast("Opening WhatsApp to connect directly with our travel manager!");
      customForm.reset();
    });
  }
}
